export interface Empleado {
    puesto: string;
    salario: number; // en USD
  }
  
  export interface Persona {
    nombre: string;
    edad: number;
    direccion: string;
    empleo: Empleado;
  }
  
 
  export const persona: Persona = {
    nombre: 'Ana Martínez',
    edad: 32,
    direccion: 'Calle Falsa 123',
    empleo: {
      puesto: 'Ingeniera de Software',
      salario: 80000
    }
  };
  
 
  export const extraerDatosPersona = (persona: Persona) => {
    const { nombre, empleo: { puesto } } = persona;
    return { nombre, puesto };
  };
  