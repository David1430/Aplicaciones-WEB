//interfaces
export interface Habilidad {
    nombre: string;
    nivel: string;
  }
  
  export interface Empleado {
    nombre: string;
    puesto: string;
    habilidades: Habilidad[];
  }
  
  export interface Proyecto {
    nombre: string;
    descripcion: string;
    empleados: Empleado[];
  }
  
//empleados
  export const empleados: Empleado[] = [
    {
      nombre: 'Juan Pérez',
      puesto: 'Desarrollador Frontend',
      habilidades: [
        { nombre: 'JavaScript', nivel: 'Avanzado' },
        { nombre: 'React', nivel: 'Intermedio' },
      ]
    },
    {
      nombre: 'María Gómez',
      puesto: 'Diseñadora',
      habilidades: [
        { nombre: 'Figma', nivel: 'Avanzado' },
        { nombre: 'Adobe XD', nivel: 'Intermedio' },
      ]
    }
  ];
  
  //proyectos
  export const proyectos: Proyecto[] = [
    {
      nombre: 'Sistema de Gestión',
      descripcion: 'Un sistema para gestionar empleados y proyectos.',
      empleados: [empleados[0], empleados[1]]
    }
  ];
  
  //Destructuración 
  const [proyecto1] = proyectos;
  const { nombre: nombreProyecto, descripcion, empleados: equipo } = proyecto1;
  
  console.log(`Proyecto: ${nombreProyecto}`);
  console.log(`Descripción: ${descripcion}`);
  equipo.forEach(({ nombre, puesto, habilidades }) => {
    console.log(`Empleado: ${nombre}, Puesto: ${puesto}`);
    habilidades.forEach(({ nombre: habilidad, nivel }) => {
      console.log(`  Habilidad: ${habilidad} (Nivel: ${nivel})`);
    });
  });
  