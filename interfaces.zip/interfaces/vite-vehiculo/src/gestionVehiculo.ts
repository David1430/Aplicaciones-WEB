export interface Vehiculo{
    marca: string;
    modelo: string;
    año: number;
  
    encender(): void;
    apagar(): void;
  }

export const auto: Vehiculo = {
    marca: 'Toyota',
    modelo: 'Corolla',
    año: 2021,
  
    encender() {console.log(`${this.marca} ${this.modelo} ${this.año} ha sido encendido.`);},
    apagar() {console.log(`${this.marca} ${this.modelo} ${this.año} ha sido apagado.`); }
  };
auto.encender(); 
auto.apagar(); 


export const vehiculo1: Vehiculo = { 
    marca: 'Honda', 
    modelo: 'Civic', 
    año: 2020, 
    encender() { console.log('Honda Civic encendido'); }, 
    apagar() { console.log('Honda Civic apagado'); } 
  };
  vehiculo1.encender(); 
  vehiculo1.apagar(); 
  
export const vehiculo2: Vehiculo = { 
    marca: 'Ford', 
    modelo: 'Focus', 
    año: 2019, 
    encender() { console.log('Ford Focus encendido'); }, 
    apagar() { console.log('Ford Focus apagado'); } 
  };
  vehiculo2.encender(); 
  vehiculo2.apagar(); 
  
export function imprimirVehiculos(vehiculos: Vehiculo[]) {
    return vehiculos.map(vehiculo => ({
      Marca: vehiculo.marca,
      Modelo: vehiculo.modelo,
      Año: vehiculo.año
    }));            
  }
  
console.table(imprimirVehiculos([auto, vehiculo1, vehiculo2]));

 
  