export interface Motor {
    tipo: string;
    potencia: number; 
  }
  
  export interface Carro {
    marca: string;
    modelo: string;
    año: number;
    motor: Motor;
  }
  
  export interface Empleado {
    nombre: string;
    carrosVendidos: Carro[];
  }
  
  
  export const empleado: Empleado = {
    nombre: 'Carlos Díaz',
    carrosVendidos: [
      {
        marca: 'Toyota',
        modelo: 'Corolla',
        año: 2022,
        motor: {
          tipo: 'Gasolina',
          potencia: 130,
        }
      },
      {
        marca: 'Honda',
        modelo: 'Civic',
        año: 2021,
        motor: {
          tipo: 'Híbrido',
          potencia: 158,
        }
      },
      {
        marca: 'Ford',
        modelo: 'Mustang',
        año: 2020,
        motor: {
          tipo: 'Gasolina',
          potencia: 450,
        }
      }
    ]
  };
  

  export const extraerDatosCarros = (empleado: Empleado) => {
    return empleado.carrosVendidos.map(({ marca, modelo, motor }) => ({
      marca,
      modelo,
      tipoMotor: motor.tipo
    }));
  };